﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula_28022024
{
    internal class Program
    {
        static void Main(string[] args)
        {
            

            foreach (Contato contato in listaContatos)
            {
                Console.WriteLine(contato.Nome);
            }
        }
    }
}
